"""Dual-target generation vs single-target generation + dual filter.
Input CSVs (columns: smiles, egfr, her2, qed, sa; Vina scores in kcal/mol, negative = better):
  dual.csv        candidates from the dual-target (RL) generator
  single_egfr.csv candidates from EGFR-only generator
  single_her2.csv candidates from HER2-only generator (both must be docked on BOTH targets)
Usage: python compare_dual_vs_filter.py dual.csv single_egfr.csv single_her2.csv [--thr -8.0]
"""
import sys, pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

def load(p): return pd.read_csv(p).dropna(subset=["egfr", "her2"]).drop_duplicates("smiles")
thr = float(sys.argv[sys.argv.index("--thr") + 1]) if "--thr" in sys.argv else -8.0
dual = load(sys.argv[1])
single = pd.concat([load(sys.argv[2]), load(sys.argv[3])]).drop_duplicates("smiles")
single_pre = single.copy()
single_f = single[(single.egfr <= thr) & (single.her2 <= thr)]   # post-filter

def stats(name, d, n_gen):
    both = d[(d.egfr <= thr) & (d.her2 <= thr)]
    return dict(method=name, n_generated=n_gen, n_unique_docked=len(d),
        dual_hit_rate=len(both) / max(len(d), 1),
        mean_egfr=d.egfr.mean(), mean_her2=d.her2.mean(),
        mean_imbalance=(d.egfr - d.her2).abs().mean(),
        mean_qed=d.qed.mean(), mean_sa=d.sa.mean(), n_dual_hits=len(both))
rows = [stats("Dual-target gen", dual, len(dual)),
        stats("Single-target gen (unfiltered)", single_pre, len(single_pre)),
        stats("Single-target gen + filter", single_f, len(single_pre))]
tab = pd.DataFrame(rows); tab.to_csv("comparison_table.csv", index=False)
print(tab.round(3).to_string(index=False))

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
for d, lab in [(single_pre, "Single, unfiltered"), (dual, "Dual-target")]:
    ax[0].scatter(d.egfr, d.her2, s=8, alpha=.5, label=lab)
ax[0].axvline(thr, ls="--", c="k"); ax[0].axhline(thr, ls="--", c="k")
ax[0].set_xlabel("EGFR Vina"); ax[0].set_ylabel("HER2 Vina"); ax[0].legend(); ax[0].set_title("Joint score space")
ax[1].bar(tab.method, tab.dual_hit_rate); ax[1].set_ylabel(f"Fraction with both ≤ {thr}")
ax[1].tick_params(axis="x", rotation=15); ax[1].set_title("Dual-hit rate")
plt.tight_layout(); plt.savefig("fig4_dual_vs_filter.png", dpi=150)
