# Dual-target (EGFR/HER2) pipeline: evaluation summary

All numbers below are the ones reported from the pipeline runs. Nothing is estimated.
The dual-target vs. single-target+filter comparison has **no data yet** (see section 4).

## 1. Docking validation (redocking of reference ligand)

| Target | Vina score (kcal/mol) | Top-pose RMSD (Å) | Best-of-poses RMSD (Å) | Result |
|---|---|---|---|---|
| EGFR | -10.72 | 1.04 | 1.04 | PASS (top pose) |
| HER2 | -11.22 | 0.71 | 0.71 | PASS (top pose) |

Both targets reproduce the reference pose under the usual 2.0 Å criterion, and the
top pose is already the best pose, so pose ranking is not the limiting factor here.
Figure: `fig1_redocking.png`.

## 2. Reward function sanity test

| Molecule | EGFR | HER2 | Reward |
|---|---|---|---|
| Lapatinib | -10.94 | -10.67 | 0.695 |
| Benzene | -4.05 | -4.65 | 0.285 |
| Invalid SMILES | n/a | n/a | -1.0 (empty dict, as designed) |

- The reward separates a known dual inhibitor from a trivial molecule on both targets.
- Lapatinib's EGFR/HER2 scores differ by only 0.27 kcal/mol, so the imbalance penalty is small.
- Invalid SMILES return -1.0 and an empty dict. The `[RDKit] ERROR` lines come from this deliberately invalid input and can be ignored.
- Lapatinib's QED is low (0.18), so its reward comes almost entirely from docking.
- Benzene earns 0.285 without binding anything. Its docking term is about 0.6 × 0.006, so almost all of it comes from QED (0.44) and SA (1.0).

**Risk:** the lapatinib-vs-benzene gap (~0.41) is workable, but an RL generator could
collect decent reward from small, easy-to-make, drug-like molecules that bind poorly.
If that happens, raise `w_dock` or lower `w_qed` / `w_sa` in `p4_config.yaml`.

**Limits of this test:** it is easy. It shows the pipeline separates a drug from a trivial molecule.
It does not show that Vina ranks *similar* compounds correctly. Vina also tends to favor larger molecules,
so read reward curves with that bias in mind.

**Open inconsistency:** lapatinib scores here (-10.94 / -10.67) differ from the redocking scores
(-10.72 / -11.22). The redocking ligand may not be lapatinib on both targets, and Vina is stochastic and
sensitive to ligand preparation. I haven't verified which applies. Run the same ligand with several seeds to get the spread.
Figure: `fig2_reward_test.png`.

## 3. Generator training progress

| Iteration | Mean reward | Valid-docked |
|---|---|---|
| 0 | 0.413 | 100% |
| 1 | 0.490 | 100% |

Mean reward rose by 0.077 (about +19%) in one iteration with no loss of validity or dockability.
Two points are not a trend. Run more iterations before drawing conclusions, and track mean EGFR/HER2
scores, QED, SA and molecular weight alongside reward to catch the size/QED shortcuts described above.
Figure: `fig3_rl_iterations.png`.

## 4. Dual-target generation vs. single-target generation + filtering: PENDING

Design to run:
- **A. Dual-target:** RL generator using the dual reward (docking on both targets, imbalance penalty, QED, SA).
- **B. Single-target + filter:** EGFR-only and HER2-only generators, every candidate docked on **both** targets, then kept only if both scores pass the threshold (default ≤ -8.0 kcal/mol).
- Use the same number of generated molecules and the same docking budget for A and B.

Metrics (produced by `compare_dual_vs_filter.py` into `comparison_table.csv` and `fig4_dual_vs_filter.png`):
dual-hit rate, number of dual hits, mean EGFR/HER2 score, mean |EGFR - HER2| imbalance, mean QED and SA.
Also compare diversity (e.g. Tanimoto) and the size of the hits, since Vina favors big molecules.

Fairness note: B's filter step is "free" only if you ignore that most of its docking budget goes to
molecules that are discarded. Report the cost per dual hit, not only the hit rate.

Run: `python compare_dual_vs_filter.py dual.csv single_egfr.csv single_her2.csv --thr -8.0`
(CSV columns: `smiles, egfr, her2, qed, sa`.) The script was smoke-tested on throwaway synthetic data only; those outputs were deleted and are not part of this report.

## Files
- `EVALUATION.md` (this file)
- `fig1_redocking.png`, `fig2_reward_test.png`, `fig3_rl_iterations.png`
- `make_eval.py` (regenerates figures 1-3)
- `compare_dual_vs_filter.py` (section 4 analysis)
