import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- 1. Redocking validation (as reported) ----
val = {"EGFR": dict(score=-10.72, rmsd=1.04), "HER2": dict(score=-11.22, rmsd=0.71)}
fig, ax = plt.subplots(1, 2, figsize=(8, 3.4))
t = list(val)
ax[0].bar(t, [val[k]["score"] for k in t], color=["#4C72B0", "#55A868"])
ax[0].set_ylabel("Vina score (kcal/mol)"); ax[0].set_title("Redocking score")
ax[1].bar(t, [val[k]["rmsd"] for k in t], color=["#4C72B0", "#55A868"])
ax[1].axhline(2.0, ls="--", c="k"); ax[1].text(1.45, 2.05, "2.0 Å pass", ha="right", fontsize=8)
ax[1].set_ylabel("Top-pose RMSD (Å)"); ax[1].set_title("Redocking RMSD"); ax[1].set_ylim(0, 2.5)
plt.tight_layout(); plt.savefig("fig1_redocking.png", dpi=150); plt.close()

# ---- 2. Reward function sanity test ----
mols = ["Lapatinib", "Benzene"]
egfr, her2, rew = [-10.94, -4.05], [-10.67, -4.65], [0.695, 0.285]
fig, ax = plt.subplots(1, 2, figsize=(8, 3.4))
x = range(2)
ax[0].bar([i - .2 for i in x], egfr, .4, label="EGFR")
ax[0].bar([i + .2 for i in x], her2, .4, label="HER2")
ax[0].set_xticks(list(x)); ax[0].set_xticklabels(mols); ax[0].set_ylabel("Vina (kcal/mol)")
ax[0].legend(); ax[0].set_title("Docking scores")
ax[1].bar(mols, rew, color=["#C44E52", "#8172B2"]); ax[1].set_ylabel("Reward")
ax[1].set_title("Reward (invalid SMILES = -1.0)")
plt.tight_layout(); plt.savefig("fig2_reward_test.png", dpi=150); plt.close()

# ---- 3. RL iterations ----
it, mr = [0, 1], [0.413, 0.490]
plt.figure(figsize=(4.5, 3.4)); plt.plot(it, mr, "o-")
plt.xticks(it); plt.xlabel("Iteration"); plt.ylabel("Mean reward")
plt.title("Mean reward (valid-docked 100%)"); plt.tight_layout()
plt.savefig("fig3_rl_iterations.png", dpi=150); plt.close()
